package no.hvl.dat107;

public class ProsjektDAO {
}
