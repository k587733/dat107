package no.hvl.dat107;

import javax.persistence.*;

@Entity
@Table(name = "Avdeling", schema = "oblig3")
public class Avdeling {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int avdelings_Id;
    private String avdelings_navn;


    public Avdeling() {
        this(0, "Prosjekt", new Ansatt());
    }

    public Avdeling(int id, String navn, Ansatt sjef) {
        this.avdelings_Id = id;
        this.avdelings_navn = navn;

    }

    public int getAvdelings_Id() {
        return avdelings_Id;
    }

//    public void setAvdelings_Id(int avdelings_Id) {
//        this.avdelings_Id = avdelings_Id;
//    }

//    public String getAvdelings_navn() {
//        return avdelings_navn;
//    }

//    public void setAvdelings_navn(String avdelings_navn) {
//        this.avdelings_navn = avdelings_navn;
//    }



}
