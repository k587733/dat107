package no.hvl.dat107;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.*;

@Entity
@Table(name = "Prosjekt", schema = "oblig3")
@NamedQuery(name = "hentAlleAnsatte", query = "SELECT p FROM Ansatt p")
public class Prosjekt {

        @Id
        private int prosjekt_Id;


        public int getProsjekt_Id() {
            return prosjekt_Id;
        }
        public void setProsjekt_Id() {
            this.prosjekt_Id = prosjekt_Id;
            //osv

    }
}
