package no.hvl.dat107;


import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Iterator;
import java.util.Scanner;


public class Main {

    public static void main(String[] args) {


            Scanner sc = new Scanner(System.in);

            int menyvalg;

            String meny = "0: Avslutt menyvalg\n" +

                          "1: Søk ansatt på ansatt id\n" +
                          "2: Søk ansatt på brukernavn\n" +
                          "3: Skriv ut alle ansatte\n" +

                          "4: Oppdater ansatt\n" +
                          "5: Legg inn ny ansatt\n" +
                          "6: Søk avdeling på avdelings id\n" +

                          "7: Skriv ut alle ansatte på en avdeling inkludert utheving av hvem som er sjef\n" +
                          "8: Oppdatere hvilken avdeling en ansatt jobber på\n" +
                          "9: Legge inn en ny avdeling\n";

            System.out.println(meny);

            boolean ferdig = false;

            Ansatt ansatt = new Ansatt();
            String brukernavn = new String();
            AnsattDAO ans = new AnsattDAO();
            AvdelingDAO avd = new AvdelingDAO();

            while ((menyvalg = sc.nextInt()) != 0) {
                switch (menyvalg) {
                    case 0:
                        //avslutt program
                        ferdig = true;
                        break;
                    case 1:
                        //søk ansatt på ansatt id
                        System.out.println("Skriv inn id på den ansatte");
                        ans.finnAnsattMedId(sc.nextInt());
                        break;
                    case 2:
                        //søk ansatt på brukernavn
                        System.out.println("Skriv inn brukernavn på den ansatte");
                        ans.finnAnsattMedBrukerNavn(sc.nextLine());
                        break;
                    case 3:
                        //skriv ut alle ansatte
                        AnsattDAO ansattDAO = new AnsattDAO();
                        ansattDAO.skrivUtAlleAnsatte();
                        break;
                    case 4:
                        //Oppdater en ansatt, endre stilling og/eller lønn
                        System.out.println("Skriv Id/Brukernavn på ansatt");
                        AnsattDAO ansattDAO1 = new AnsattDAO();
                        ansattDAO1.oppdaterAnsatt(ansatt);
                        break;
                    case 5:
                        //legg inn ny ansatt
                        System.out.println("Oppgi brukernavn");
                        brukernavn = sc.nextLine();
                        System.out.println("Oppgi fornavn");
                        String fornavn = sc.nextLine();
                        System.out.println("Oppgi etternavn");
                        String etternavn = sc.nextLine();
                        System.out.println("Skriv inn ansettelsesdato, ÅÅÅÅ-MM-DD");
                        LocalDate ansatt_dato = LocalDate.parse(sc.nextLine());
                        System.out.println("Oppgi stilling");
                        String stilling = sc.nextLine();
                        System.out.println("Oppgi månedslønn");
                        int manedslonn = Integer.valueOf(sc.nextLine());
                        System.out.println("Oppgi avdeling");
                        String avdeling = sc.nextLine();


                        AnsattDAO ansattDAO2 = new AnsattDAO();
                        ansattDAO2.leggTilAnsatt(ansatt);
                        ansattDAO2.skrivUtTabell();
                        break;
                    case 6:
                        //søk avdeling på avdelings id
                        System.out.println("Skriv inn id på avdeling");
                        avd.finnAvdelingMedId(sc.nextInt());
                        break;
                    case 7:
                        //Skriv ut alle ansatte på en avdeling inkludert utheving av hvem som er sjef
                        break;
                    case 8:
                        //Oppdatere hvilken avdeling en ansatt jobber på
                        break;
                    case 9:
                        //Legge inn en ny avdeling
                        break;
                    default:
                }
                System.out.println("Trykk et tall for ønsket valg");
                System.out.println(meny);
            }

        }
    }

