package no.hvl.dat107;

import java.time.LocalDate;
import javax.persistence.*;


@Entity
@Table(name = "Ansatt", schema = "oblig3")
public class Ansatt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int ansatt_Id;
    private double manedslonn;
    private LocalDate ansatt_dato;
    private String brukernavn;
    private String fornavn;
    private String etternavn;
    private String stilling;

    @OneToOne
    @JoinColumn(name = "Avdeling", referencedColumnName = "Avdelings_Id")
    private Avdeling avdeling;

    public Ansatt() {

    }


    public Ansatt(String fornavn, String etternavn, String stilling, double manedslonn , Avdeling avdeling){
        this(fornavn, etternavn, null, stilling, manedslonn, avdeling);
    }

    public Ansatt(String fornavn, String etternavn, LocalDate datoforansettelse,
                    String stilling, double mandeslonn, Avdeling avdeling){

        this.brukernavn = (fornavn.substring(0, 2) + etternavn.substring(0, 2).toLowerCase());
        this.fornavn = fornavn;
        this.etternavn = etternavn;
        if(datoforansettelse == null){
            datoforansettelse = LocalDate.now();
        }
        this.stilling = stilling;
        this.manedslonn = mandeslonn;
        this.avdeling = avdeling;
    }

    public int getAnsatt_Id() {
        return ansatt_Id;
    }

    public void setAnsatt_Id(int ansatt_Id) {
        this.ansatt_Id = ansatt_Id;
    }

    public double getManedslonn() {
        return manedslonn;
    }

    public void setManedslonn(double manedslonn) {
        this.manedslonn = manedslonn;
    }

    public LocalDate getAnsatt_dato() {
        return ansatt_dato;
    }

    public void setAnsatt_dato() {
        this.ansatt_dato = ansatt_dato;
    }

    public String getBrukernavn() {
        return brukernavn;
    }

    public void setBrukernavn(String brukernavn) {
        this.brukernavn = brukernavn;
    }

    public String getFornavn() {
        return fornavn;
    }

    public void setFornavn(String fornavn) {
        this.fornavn = fornavn;
    }

    public String getEtternavn() {
        return etternavn;
    }

    public void setEtternavn(String etternavn) {
        this.etternavn = etternavn;
    }

    public String getStilling() {
        return stilling;
    }

    public void setStilling(String stilling) {
        this.stilling = stilling;
    }

    public Avdeling getAvdeling() {
        return avdeling;
    }

    public void setAvdeling(Avdeling avdeling) {
        this.avdeling = avdeling;
    }

    @Override
    public String toString() {
        return  "{ Ansatt_Id: " + ansatt_Id +
                "| Brukernavn: "  + brukernavn +
                "| Fornavn: " + fornavn +
                "| Etternavn: " + etternavn +
                "| Ansatt_dato: " + ansatt_dato +
                "| Stilling: " + stilling +
                "| Maanedslonn: " + manedslonn +
                "| Avdeling: " + avdeling + " }";

    }
}


