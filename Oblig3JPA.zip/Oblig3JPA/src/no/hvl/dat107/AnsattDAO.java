package no.hvl.dat107;

import java.time.LocalDate;
import java.util.List;
import javax.persistence.*;

public class AnsattDAO {

    private EntityManagerFactory emf;

    public AnsattDAO() {
        emf = Persistence.createEntityManagerFactory("ansattPersistenceUnit");
    }

    public Ansatt finnAnsattMedId(int ansatt_Id) {
        EntityManager em = emf.createEntityManager();
        Ansatt a = null;
        try {

            a= em.find(Ansatt.class, ansatt_Id);

        } finally {
            em.close();

        }
        return a;
    }

    public List<Ansatt> finnAnsattMedBrukerNavn(String brukernavn){

        EntityManager em = emf.createEntityManager();

        try{

            TypedQuery<Ansatt> query = em.createQuery("select a from Ansatt a where a.brukernavn = :brukernavn", Ansatt.class);

            query.setParameter("brukernavn", brukernavn);

            return query.getResultList();
        }finally{

            em.close();
        }
    }

    public List<Ansatt> skrivUtAlleAnsatte() {

        EntityManager em = emf.createEntityManager();

        List<Ansatt> ansatte = null;

        try{

            TypedQuery<Ansatt> query = em.createQuery("select a from Ansatt a", Ansatt.class);

            ansatte = query.getResultList();
        }finally {
            em.close();
        }

        return ansatte;
    }

    public void oppdaterAnsatt(Ansatt ansatt) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();
            em.persist(ansatt);
            tx.commit();

        } catch (Throwable e) {
            e.printStackTrace();
            tx.rollback();

        } finally {
            em.close();
        }
    }

    public void leggTilAnsatt(Ansatt ansatt) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();

        try {
            tx.begin();
            em.persist(ansatt);
            tx.commit();

        } catch(Throwable e){
            e.printStackTrace();
            tx.rollback();

        } finally {
            em.close();
        }
    }

    public void skrivUtTabell() {

    }


}
