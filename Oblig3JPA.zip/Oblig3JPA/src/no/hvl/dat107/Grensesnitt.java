package no.hvl.dat107;

import javax.persistence.*;
import no.hvl.dat107.Ansatt;
import no.hvl.dat107.Avdeling;
import java.util.Scanner;


public class Grensesnitt {

    private AnsattDAO ansattDAO;
    private AvdelingDAO avdelingDAO;
    private ProsjektDAO prosjektDAO;
    private AnsattProsjektDAO ansattProsjektDAO;

    public Grensesnitt() {

        this.ansattDAO = new AnsattDAO();
        this.avdelingDAO = new AvdelingDAO();
        this.prosjektDAO = new ProsjektDAO();
        this.ansattProsjektDAO = new AnsattProsjektDAO();


    }

    private void clear() {

        System.out.println("Velkommen til Obligatorisk innlevering 3, i DAT107\n");

        Ansatt test = ansattDAO.finnAnsattMedId(1);
        System.out.println(test.getBrukernavn());

        // Start meny-løkke
        boolean done = false;
        while (!done) {
            done = this.meny();
        }
    }

    public void start() {

        clear();

        System.out.println("Velkommen til Obligatorisk innlevering 3, i DAT107\n");

        Ansatt test = ansattDAO.finnAnsattMedId(1);
        System.out.println(test.getBrukernavn());

        // Start meny-løkke
        boolean done = false;
        while (!done) {
            done = this.meny();
        }
    }

        Scanner sc = new Scanner(System.in);

        private boolean meny () {
            System.out.println("Følgende valg er tilgjengelige:\n");

            System.out.println("  1. Utforsk ansatte");
            System.out.println("  2. Utforsk avdelinger");
            System.out.println("  3. Utforsk prosjekter\n");

            System.out.println("  4. Legg til ansatt");
            System.out.println("  5. Legg til avdeling");
            System.out.println("  6. Legg til prosjekt\n");

            System.out.println("  7. Fjern ansatt");
            System.out.println("  8. Fjern avdeling");
            System.out.println("  9. Fjern prosjekt\n");

            System.out.println(" 10. Avslutt program");

            System.out.println("\nSkriv inn tallet ved ditt ønskede valg");

            int input;

            try {
                input = Integer.parseInt(receiveInput());
            } catch (NumberFormatException ex) {
                System.out.println("\nSkriv inn et tall.\n");

            }
            return false;
        }


            private void leggTilAnsatt () {
                clear();
                System.out.println("Legg til ansatt\n");

                Ansatt a = new Ansatt();

                System.out.println("Fornavn?");
                a.setFornavn(receiveInput());

                System.out.println("Etternavn?");
                a.setEtternavn(receiveInput());

                System.out.println("Stilling?");
                a.setEtternavn(receiveInput());

                System.out.println("Månedslønn?");
                boolean done = false;
                while (!done) {
                    try {
                        a.setManedslonn(Integer.parseInt(receiveInput()));
                        done = true;
                    } catch (NumberFormatException ex) {
                        System.out.println("Skriv inn et gyldig tall.");
                    }
                }


            	System.out.println("Etternavn?");
		a.setEtternavn(receiveInput());

		ansattDAO.leggTilAnsatt(a);
}

            private String receiveInput () {
                System.out.print("> ");
                String s = System.console().readLine();
                System.out.println();

                return s;
            }
        }








