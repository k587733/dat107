-- SQL for Oblig3 (nullstiller database)

DROP SCHEMA IF EXISTS Oblig3 CASCADE;
CREATE SCHEMA Oblig3;
SET search_path TO Oblig3;

DROP TABLE IF EXISTS Ansatt;
DROP TABLE IF EXISTS Avdeling;
DROP TABLE IF EXISTS Prosjekt;
DROP TABLE IF EXISTS AnsattProsjekt;

-- Oppretter tabeller og relasjoner

CREATE TABLE Ansatt (
    Ansatt_Id SERIAL,
	Brukernavn VARCHAR(32),
	Fornavn VARCHAR(32) NOT NULL,
	Etternavn VARCHAR(32) NOT NULL,
	Ansatt_dato DATE,
	Stilling VARCHAR(32),
	Manedslonn INTEGER,

	CONSTRAINT ansattPK PRIMARY KEY (Ansatt_Id),
	UNIQUE (Ansatt_Id, Brukernavn)
);

CREATE TABLE Avdeling (

    Avdelings_Id SERIAL,
    Avdelings_Navn VARCHAR(32),

    CONSTRAINT Avdeling_PK PRIMARY KEY (Avdelings_Id),
    UNIQUE (Avdelings_Id)
);

CREATE TABLE Prosjekt (
    Prosjekt_Id SERIAL,
    Prosjekt_Navn VARCHAR(32),
    Beskrivelse VARCHAR(255),
    Ansatte INTEGER,

    CONSTRAINT Prosjekt_PK PRIMARY KEY (Prosjekt_Id),
    UNIQUE (Prosjekt_Id)
);

CREATE TABLE AnsattProsjekt (
     Ansatt_Id INTEGER REFERENCES Ansatt(Ansatt_Id),
     Prosjekt_Id INTEGER REFERENCES Prosjekt(Prosjekt_Id),
     Timer INTEGER,
     Rolle VARCHAR(32),

     CONSTRAINT AnsattProsjektPK PRIMARY KEY (Ansatt_Id, Prosjekt_Id)
);



